package com.ditzz.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Map;

/** Fitur tambahan: Aim Assist (speed + prediction) dan Entity Control (speed). */
public class Extras {
    // Aim Assist
    public static boolean aimAssist = false;
    public static float aimSpeed = 0.25f;      // 0.05 - 1.0 (makin besar makin cepat narik)
    public static float aimPrediction = 2.0f;  // tick ke depan (0 = mati)
    public static float aimRange = 4.5f;
    public static float aimFov = 60f;

    // Entity Control
    public static boolean entityControl = false;
    public static float entitySpeed = 0.6f;    // 0.1 - 3.0

    private static Map<Integer, Vec3d> lastPos = new HashMap<>();

    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) { lastPos.clear(); return; }
        if (aimAssist) aim(mc); else lastPos.clear();
        if (entityControl) control(mc);
    }

    // ---------- Aim Assist ----------
    private static void aim(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        Vec3d eye = p.getEyePos();
        Map<Integer, Vec3d> now = new HashMap<>();
        double best = Double.MAX_VALUE;
        float bdy = 0, bdp = 0;
        boolean found = false;

        for (PlayerEntity t : mc.world.getPlayers()) {
            if (t == p || !t.isAlive()) continue;
            Vec3d c = t.getBoundingBox().getCenter();
            now.put(t.getId(), c);
            if (mc.currentScreen != null || p.distanceTo(t) > aimRange) continue;

            // Prediction: gerakan target per tick (horizontal) dikali jumlah tick ke depan
            Vec3d prev = lastPos.get(t.getId());
            Vec3d aimPoint = c;
            if (prev != null && aimPrediction > 0f) {
                aimPoint = c.add((c.x - prev.x) * aimPrediction, 0, (c.z - prev.z) * aimPrediction);
            }

            Vec3d to = aimPoint.subtract(eye);
            float ty = (float) (MathHelper.atan2(to.z, to.x) * 180 / Math.PI) - 90f;
            float tp = (float) -(MathHelper.atan2(to.y, Math.hypot(to.x, to.z)) * 180 / Math.PI);
            float dy = MathHelper.wrapDegrees(ty - p.getYaw());
            float dp = tp - p.getPitch();
            double ang = Math.hypot(dy, dp);
            if (ang > aimFov || ang >= best) continue;
            best = ang; bdy = dy; bdp = dp; found = true;
        }
        lastPos = now;

        if (!found) return;
        p.setYaw(p.getYaw() + bdy * aimSpeed);
        p.setPitch(MathHelper.clamp(p.getPitch() + bdp * aimSpeed, -90f, 90f));
    }

    // ---------- Entity Control ----------
    private static void control(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        Entity v = p.getVehicle();
        if (v == null) return;

        double yaw = Math.toRadians(p.getYaw());
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);   // depan
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);  // kanan

        double f = (mc.options.forwardKey.isPressed() ? 1 : 0) - (mc.options.backKey.isPressed() ? 1 : 0);
        double r = (mc.options.rightKey.isPressed() ? 1 : 0) - (mc.options.leftKey.isPressed() ? 1 : 0);
        double dx = fx * f + rx * r, dz = fz * f + rz * r;
        double len = Math.hypot(dx, dz);
        if (len > 1.0E-4) { dx = dx / len * entitySpeed; dz = dz / len * entitySpeed; }
        else { dx = 0; dz = 0; }

        double y = v.getVelocity().y;
        if (mc.options.jumpKey.isPressed()) y = 0.3;

        v.setYaw(p.getYaw());
        v.setVelocity(dx, y, dz);
    }
}
