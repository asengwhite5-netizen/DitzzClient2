package com.ditzz.client.mixin;

import com.ditzz.client.DitzzClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerInteractionManager.class)
public abstract class InteractionManagerMixin {
    @Inject(method = "attackEntity", at = @At("HEAD"))
    private void ditzz$slamStun(PlayerEntity player, Entity target, CallbackInfo ci) {
        DitzzClient.onAttack(player, target);
    }
}
