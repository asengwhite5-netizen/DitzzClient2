package com.ditzz.client.mixin;

import com.ditzz.client.DitzzClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(SimpleOption.class)
public abstract class SimpleOptionMixin {
    // Brightness (fullbright): paksa nilai gamma jadi tinggi selama Brightness ON
    @Inject(method = "getValue", at = @At("RETURN"), cancellable = true)
    private void ditzz$gamma(CallbackInfoReturnable<Object> cir) {
        if (!DitzzClient.brightness) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.options == null) return;
        if ((Object) this == mc.options.getGamma()) cir.setReturnValue(Double.valueOf(16.0));
    }
}
