package com.ditzz.client.gui;

import com.ditzz.client.DitzzClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import com.ditzz.client.Extras;

public class DitzzScreen extends Screen {
    private static final int PW = 440, PH = 240;

    public DitzzScreen() {
        super(Text.literal(DitzzClient.NAME));
    }

    private int px() { return (this.width - PW) / 2; }
    private int py() { return (this.height - PH) / 2; }

    @Override
    protected void init() {
        int x = px() + 20;
        int y = py() + 34;
        int w = 190;
        int x2 = px() + 230;

        toggle(x, y,       w, "SlamStun (manual click)", () -> DitzzClient.slamStun,   v -> DitzzClient.slamStun = v);
        toggle(x, y + 26,  w, "AntiInvis",               () -> DitzzClient.antiInvis,  v -> DitzzClient.antiInvis = v);
        toggle(x, y + 52,  w, "Hitbox",                  () -> DitzzClient.hitbox,     v -> DitzzClient.hitbox = v);
        toggle(x, y + 78,  w, "Brightness",              () -> DitzzClient.brightness, v -> DitzzClient.brightness = v);
        toggle(x, y + 104, w, "AimAssist",               () -> Extras.aimAssist,       v -> Extras.aimAssist = v);
        toggle(x, y + 130, w, "EntityControl",           () -> Extras.entityControl,   v -> Extras.entityControl = v);

        this.addDrawableChild(new HitboxSlider(x2, y, w, 20));
        this.addDrawableChild(new ValueSlider(x2, y + 26, w, 20, "Aim Speed", 0.05f, 1.0f, Extras.aimSpeed,
                v -> Extras.aimSpeed = v, "%.2f"));
        this.addDrawableChild(new ValueSlider(x2, y + 52, w, 20, "Aim Prediction", 0.0f, 10.0f, Extras.aimPrediction,
                v -> Extras.aimPrediction = v, "%.1f"));
        this.addDrawableChild(new ValueSlider(x2, y + 78, w, 20, "Entity Speed", 0.1f, 3.0f, Extras.entitySpeed,
                v -> Extras.entitySpeed = v, "%.2f"));

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> this.close())
                .dimensions(x, y + 166, PW - 40, 20).build());
    }

    private void toggle(int x, int y, int w, String name, BooleanSupplier get, Consumer<Boolean> set) {
        ButtonWidget[] ref = new ButtonWidget[1];
        ref[0] = ButtonWidget.builder(label(name, get.getAsBoolean()), b -> {
            set.accept(!get.getAsBoolean());
            b.setMessage(label(name, get.getAsBoolean()));
        }).dimensions(x, y, w, 20).build();
        this.addDrawableChild(ref[0]);
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "§aON" : "§cOFF"));
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.renderBackground(ctx, mouseX, mouseY, delta);
        int x = px(), y = py();
        ctx.fill(x - 1, y - 1, x + PW + 1, y + PH + 1, 0xFF00C8FF); // border
        ctx.fill(x, y, x + PW, y + PH, 0xE0101018);                 // panel
        ctx.fill(x, y, x + PW, y + 24, 0xFF1A1A2E);                 // header
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        String title = "§b§l" + DitzzClient.NAME;
        int tw = this.textRenderer.getWidth(title);
        ctx.drawTextWithShadow(this.textRenderer, Text.literal(title), px() + (PW - tw) / 2, py() + 8, 0xFFFFFFFF);
        ctx.drawTextWithShadow(this.textRenderer, Text.literal("RShift = menu | J K L M N B = toggle"),
                px() + 20, py() + PH - 14, 0xFF888899);
    }

    @Override
    public boolean shouldPause() { return false; }

    private static class ValueSlider extends SliderWidget {
        private final String name;
        private final float min, max;
        private final Consumer<Float> set;
        private final String fmt;

        ValueSlider(int x, int y, int w, int h, String name, float min, float max, float cur,
                    Consumer<Float> set, String fmt) {
            super(x, y, w, h, Text.empty(), (cur - min) / (max - min));
            this.name = name; this.min = min; this.max = max; this.set = set; this.fmt = fmt;
            updateMessage();
        }
        private float cur() { return min + (float) this.value * (max - min); }
        @Override
        protected void updateMessage() {
            if (name == null) return;
            this.setMessage(Text.literal(name + ": " + String.format(fmt, cur())));
        }
        @Override
        protected void applyValue() { set.accept(cur()); }
    }

    private static class HitboxSlider extends SliderWidget {
        HitboxSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), DitzzClient.hitboxExpand); // 0.0 - 1.0 blok
            updateMessage();
        }
        @Override
        protected void updateMessage() {
            this.setMessage(Text.literal(String.format("Hitbox Size: +%.2f", (float) this.value)));
        }
        @Override
        protected void applyValue() {
            DitzzClient.hitboxExpand = (float) this.value;
        }
    }
}
